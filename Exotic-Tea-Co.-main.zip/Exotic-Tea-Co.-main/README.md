# Exotic-Tea-Co.
Developed a full-stack, responsive e-commerce website for Exotic Tea Co. using HTML, CSS, JavaScript, PHP, and SQL. Leveraged XAMPP for backend development. The project resulted in a complete and visually appealing website, ready for deployment, showcasing various teas and enabling seamless online transactions.
I have provided the full code for the website(all HTML CSS JS PHP files).
You only need to have the following installed:
~PHP
~XAMPP server( with Apache and SQL Working and connected in it).
here's a preview:
![29bbb68510c3a87b29ba2b0b33668e92c6279ad3](https://github.com/user-attachments/assets/9417c8c5-1de5-4167-a0c9-413e63c2950b)
![070fe012f544f2d488a5b67647e7c41d035bf4d8](https://github.com/user-attachments/assets/707bd86e-705f-4e6f-9d69-f2f1c8ae396c)
![ecbc1e57af2d5f92275e1174fd49d92c2efd5274](https://github.com/user-attachments/assets/ec5d8b71-7112-41d1-b965-b761dbe5db99)
![bacb1624f661d2204b54247dcd513da967e6928e](https://github.com/user-attachments/assets/50df399e-d6bf-45eb-b711-79d30a8f5f3d)
![2898cd9778e578e4963288cff523c81944815d2e](https://github.com/user-attachments/assets/05d5bd4f-4095-4f3e-8104-e3c8d16f3fc4)
![b2878b54303cec6d91f3d7f5d3f34359e9973ce5](https://github.com/user-attachments/assets/0fce7d95-b4df-410c-8d3c-0e0f7497ae42)
![a5526fa4a1e334215f8afabb26c52dcafda7f920](https://github.com/user-attachments/assets/ce626ec9-4c1d-43a5-bd9d-8a25911d3d03)
